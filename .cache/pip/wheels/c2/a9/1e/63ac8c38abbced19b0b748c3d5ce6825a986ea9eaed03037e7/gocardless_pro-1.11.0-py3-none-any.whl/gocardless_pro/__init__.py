"""A client library for the GoCardless Pro API."""

from .client import Client

__version__ = '1.11.0'

